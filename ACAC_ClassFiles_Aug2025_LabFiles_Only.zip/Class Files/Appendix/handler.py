import json
import boto3
import pprint

client = boto3.client("dynamodb")


def DBread(event, context):
    account = event["Details"]["ContactData"]["Attributes"]["account"]
    print(account)
    data = client.get_item(
        TableName="ConnectDB", Key={"acctNumber": {"N": account}}
    )
    print(data)
    response = {
        "statusCode": 200,
        "body": json.dumps(data),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
    }

    body = json.loads(
        response["body"]
    )  # body contents are a dictionary in a string, this converts to a proper dictionary
    # Extract the content of the body to variables
    # acctNumber = body['Item']['acctNumber']['N']
    # firstName = body['Item']['firstName']['S']
    # lastName = body['Item']['fastName']['S']
    # serviceLevel = body['Item']['serviceLevel']['S']
    # rewrite the response to flatten the desired nested values
    response = {
        "statusCode": 200,
        "acctNumber": body["Item"]["acctNumber"]["N"],
        "firstName": body["Item"]["firstName"]["S"],
        "lastName": body["Item"]["lastName"]["S"],
        "serviceLevel": body["Item"]["serviceLevel"]["S"],
    }
    pprint.pprint(response)
    return response
