import boto3
import time

dbName = "CustomerDB"
dynamodb = boto3.resource("dynamodb")

table = dynamodb.create_table(
    TableName=dbName,
    KeySchema=[{"AttributeName": "acctNumber", "KeyType": "HASH"}],
    AttributeDefinitions=[
        {"AttributeName": "acctNumber", "AttributeType": "N"}
    ],
    ProvisionedThroughput={"ReadCapacityUnits": 1, "WriteCapacityUnits": 1},
)
print(table)
table = dynamodb.Table(dbName)
time.sleep(10)
with table.batch_writer() as batch:
    batch.put_item(
        Item={
            "firstName": "Jed",
            "lastName": "Demeule",
            "serviceLevel": "Silver",
            "acctNumber": 1001,
        }
    )
    batch.put_item(
        Item={
            "firstName": "Mike",
            "lastName": "Keitzer",
            "serviceLevel": "Gold",
            "acctNumber": 1002,
        }
    )
    batch.put_item(
        Item={
            "firstName": "Bruce",
            "lastName": "Wilkenson",
            "serviceLevel": "Platinum",
            "acctNumber": 1003,
        }
    )
print(batch)
